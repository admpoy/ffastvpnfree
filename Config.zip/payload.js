
[
 {
	  "Name":"SUN - TU #1",
	  "Info":"TU Promo #1",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09F97FA0EFA08FD6FA0CF97FA09FA0AFD6FA08FA0EFAA0FA0AFD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #2",
	  "Info":"TU Promo #2",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #3",
	  "Info":"TU Promo #3",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAA9FA0AF99FA0DF97FAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #4",
	  "Info":"TU Promo #4",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA9FAB0FD6FAACFA08FAAAFA0CFAAAFD6F99FAA0F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - TU #5",
	  "Info":"TU Promo #5",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FAA9FA0AF99FA0DF97FAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - NONSTOP PROMO",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAAEFAABFA0EFAA0FAA0FA0AFAADFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN - MSG PROMO",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A08F97FAA0FD6FA08FA0EFAA0FA0AFD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN- CTC PROMO",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AAAFDEFAAAFD6FAABFAADFA0AFA0BFA0AFAADFAADFA0AFA00FD6FAAEFA06F99FD8FEEFAAEFD9FECFD6FAA8FD9FE6FD6FA08FAAEF99F97F99FA0DFA0AFD9FD6F99FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SUN TU [NO BLOCK TEST]",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA6FAA8FD6FAA6FAADFAA7FA0AFA08FA0EFA0BFA0AFD6F99FAAAFA09FD6FA07FA0EF97FAA6FAAEFAA6F97FAA6FA0EF99FD6F99FAAAFA09FD6FAA6FA08F99FA00FAA0FECFD6F99FAAAFA09FD6FA08FA0EFAA0FA0AFD6FAA0F97FAA8FA0AFAADFD6FA06FAABFD6FA0BF98FD6FA09FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
  {
	  "Name":"SUN FB PROMO [BETA]",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AAEFAA0F97FAABFAA6FAA7FDEFA09FA0EFAA0FA0EFD6FA0BF97F99FA0AF98FAAAFAAAFA07FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TM - A20",
	  "Info":"A20 TO 8080 RANDOM CAPP",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A0AFAA0F99FAADFABAFAABFAA6FA0AFA00FDEFAA6F98FAA0FEAFD6FA0CFAAEFAA6F97FAA6FA0EF99FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TM - ASTIGFB10/15",
	  "Info":"ASTIGFB10/15 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"97FAABFAABFAAEFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09FD6FAABFA0EF99F97FAAEF97FD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GSWITCH #1",
	  "Info":"Accet Offer",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GSWITCH #2",
	  "Info":"Accet Offer",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM - PROMO #1",
	  "Info":"Accet Offer",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AAEFAA7FAADFA0BF97FA08FA0AFAADFAA6FD6FA0CFA08FAAAF98FA0AFD6F99FAAAFA09FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM - PROMO #2",
	  "Info":"Accet Offer",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A00FA0AFAA9FD6FA08FAAAFAA6FAA7FAAEFA0BF97FAADFA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM FB Promo",
	  "Info":"Any Fb Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GoWatch #1",
	  "Info":"GOSURF50/EZ50 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A0BFAADFA0AFA0AFABAFAAAFAA7FAA6FAA7F98FA0AFD6FAAEFAA7FAA0F98FAADFAAAF97FA00F98F97FAA0FA00FD6F99FAAAFA09FD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM GoWatch #2",
	  "Info":"GOSURF50/EZ50 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FA0CFAAAFAAAFA0CFA08FA0AFAA8FA0EFA00FA0AFAAAFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"GTM Gowatch/nrg/Gswitch",
	  "Info":"GOSURF50/EZ50 TO 8080",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AAEFD6FABAFAA6FA0EFA09FA0CFD6F99FAAAFA09FE9FA0EFAABFAA8FEBFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09FE9FA09FD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"ALL NETWORK",
	  "Info":"Youtube Promo #1",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"ALLNETWORK",
	  "Info":"Youtube Promo #2",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"ABAFAA6FEAFD6FA0CFA0CFAABFA0DFAA6FD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - IG10 PROMO",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"m.instagram.com-ffast.zxc.yt",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAA8FA0EF98FA0AFAADFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - CHOOSE PROMO",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FAA8FA0EF98FA0AFAADFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - PC30 PROMO #1",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - PC30 PROMO #2",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - SC20 PROMO #1",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"A0DFAA6FAA6FAABFAAEFE8FD7FD7FA09FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09FD7FAA7FAAEFA0AFAADFD7FAAEFA09F97FAADFAA6F99FAAAFAADFAABFAAAFAADF97FAA6FA0AF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"TNT - SC20 PROMO #2",
	  "Info":"SC Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FABAFAAAFAA7FAA6FAA7F98FA0AFD6F99FAAAFA09FE8F99FA08FA0EFA0AFAA0FAA6FAAEFEAFD6FA0CFAAAFAAAFA0CFA08FA0AFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART - GIGA SURF",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"AA9FAA9FAA9FD6FA0CFAAAFAAAFA0CFA08FA0AFAA8FA0EFA00FA0AFAAAFD6F99FAAAFA09F",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		      "Back-Querry":true,
		  "Keep-Alive":true
	  }
  },
{
	  "Name":"SMART - No-Load",
	  "Info":"ALLOUT Promo",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"68.183.180.37",
			  "Port":"8080"
		  },
		  "Url":"7AF97FA09FA0AFAB0FD6FAAAFAADFA0CFD6FAABFA0DF",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":false,
		  "Reverse-Proxy":false,
		      "Back-Querry":false,
		  "Keep-Alive":true
	  }
  },
]